package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.conn.DbConnect;
import com.dao.ContactDAO;

@WebServlet("/deleteContact")
public class DeleteContact extends HttpServlet {
	protected void doGet(HttpServletRequest req,HttpServletResponse resp)
	throws ServletException,IOException{  
	int id=Integer.parseInt(req.getParameter("id"));
	new ContactDAO(DbConnect.getConn()).deleteContact(id);
	resp.sendRedirect("viewContact");
	}

}
