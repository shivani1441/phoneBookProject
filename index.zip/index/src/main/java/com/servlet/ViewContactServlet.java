package com.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.conn.DbConnect;
import com.dao.ContactDAO;
import com.entity.Contact;
@WebServlet("/viewContact")
public class ViewContactServlet extends HttpServlet {
	protected void doGet(HttpServletRequest req,HttpServletResponse resp)
	throws ServletException,IOException{ 
    ContactDAO dao=new ContactDAO(DbConnect.getConn());
    List<Contact> list=dao.getAllContacts();
    req.setAttribute("contactList",list);
    req.getRequestDispatcher("view_contact.jsp").forward(req,resp);
}
}
