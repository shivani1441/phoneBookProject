package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.conn.DbConnect;
import com.dao.ContactDAO;
import com.entity.Contact;

@WebServlet("/editContact")
public class EditContact extends HttpServlet {
	protected void doGet(HttpServletRequest req,HttpServletResponse resp)
	throws ServletException,IOException{ 
		int id=Integer.parseInt(req.getParameter("id"));
		ContactDAO dao=new ContactDAO(DbConnect.getConn());
		Contact c=dao.getContactById(id);
		req.setAttribute("contact", c);
		req.getRequestDispatcher("EditContact.jsp").forward(req, resp);
	}
	protected void doPost(HttpServletRequest req,HttpServletResponse resp)
			throws ServletException,IOException{
		Contact c=new Contact();
		c.setId(Integer.parseInt(req.getParameter("id")));
		c.setName(req.getParameter("name"));
		c.setEmail(req.getParameter("email"));
		c.setPhno(req.getParameter("phone"));
		c.setAbout(req.getParameter("about"));
		new ContactDAO(DbConnect.getConn()).updateContact(c);
		resp.sendRedirect("viewContact");
		
	}
}
