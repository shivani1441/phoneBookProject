package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Contact;

public class ContactDAO {
private Connection conn;
public ContactDAO(Connection conn) {
	this.conn=conn;
}
public boolean saveContact(Contact c) {
	String sql="insert into contact(userid,name,email,phno,about) values(?,?,?,?,?)";
	try(PreparedStatement ps=conn.prepareStatement(sql)){
		ps.setInt(1, c.getId());;
		ps.setString(2,c.getName());
		ps.setString(3,c.getEmail());
		ps.setString(4,c.getPhno());
		ps.setString(5,c.getAbout());
		return ps.executeUpdate()==1;
	}catch(Exception e) {
		e.printStackTrace();
		return false;
	}
			
}
public List<Contact>getAllContacts(){
	List<Contact>list=new ArrayList<>();
	String sql="select *from contact";
	try(PreparedStatement ps=conn.prepareStatement(sql)){
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			Contact c=new Contact();
			c.setId(rs.getInt("id"));
			c.setName(rs.getString("name"));
			c.setEmail(rs.getString("email"));
			c.setPhno(rs.getString("phno"));
			c.setAbout(rs.getString("about"));
			list.add(c);
			
		}
	}catch(Exception e) {
		e.printStackTrace();
	}
	return list;
}
public Contact getContactById(int id) {
	
	try {
		String sql="Select id,name,email,phno,about from contact where id=?";
		var ps=conn.prepareStatement(sql);
		ps.setInt(1, id);
		var rs=ps.executeQuery();
		if(rs.next()) {
			Contact c=new Contact();
			c.setId(rs.getInt("id"));
			c.setName(rs.getString("name"));
			c.setEmail(rs.getString("email"));
			c.setPhno(rs.getString("phno"));
			c.setAbout(rs.getString("about"));
			return c;
		}
	}catch(Exception e) {
		e.printStackTrace();
	}
	return null;
}
public boolean updateContact(Contact c) {
	try {
		String sql="update contact set name=?,email=?,phno=?,about=? where id=?";
		var ps=conn.prepareStatement(sql);
		ps.setString(1, c.getName());
		ps.setString(2, c.getEmail());
		ps.setString(3, c.getPhno());
		ps.setString(4, c.getAbout());
		ps.setInt(5, c.getId());
		
		 return ps.executeUpdate() == 1; 
	}catch(Exception e) {
		e.printStackTrace();
	}
	return false;
}
public boolean deleteContact(int id) {
	try {
		String sql="delete from contact where id=?";
		var ps=conn.prepareStatement(sql);
		ps.setInt(1, id);
		ps.executeUpdate();
		return true;
	}catch(Exception e) {
		e.printStackTrace();
	}
	return false;
}
}

